import React, { useState, useEffect } from 'react';
import './CrearLocalPage.scss';
import { useParams, useNavigate } from 'react-router-dom';
import { obtenerLocalPorId, actualizarLocal, obtenerVendedores } from '../../services/localesService';
import Toast from '../../components/Toast';
import Nav from '../../components/Nav';

const EditarLocalPage = () => {
    const { id } = useParams();
    const [nombre, setNombre] = useState('');
    const [direccion, setDireccion] = useState('');
    const [vendedores, setVendedores] = useState([]);
    const [vendedoresSeleccionados, setVendedoresSeleccionados] = useState([]);
    const [toast, setToast] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [local, todosLosVendedores] = await Promise.all([
                    obtenerLocalPorId(id),
                    obtenerVendedores()
                ]);
                setNombre(local.nombre);
                setDireccion(local.direccion);
                setVendedores(todosLosVendedores);
                setVendedoresSeleccionados(local.vendedores.map(v => v._id));
            } catch (error) {
                console.error('Error al cargar datos del local:', error);
                setToast({ message: 'Error al cargar datos', state: 'danger' });
            }
        };
        fetchData();
    }, [id]);

    const handleCheckboxChange = (id) => {
        if (vendedoresSeleccionados.includes(id)) {
            setVendedoresSeleccionados(prev => prev.filter(v => v !== id));
        } else {
            if (vendedoresSeleccionados.length < 4) {
                setVendedoresSeleccionados(prev => [...prev, id]);
            } else {
                setToast({ message: 'Máximo 4 vendedores por local', state: 'danger' });
                setTimeout(() => setToast(null), 3000);
            }
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await actualizarLocal(id, {
                nombre,
                direccion,
                vendedores: vendedoresSeleccionados
            });
            setToast({ message: 'Local actualizado correctamente', state: 'success' });
            setTimeout(() => {
                setToast(null);
                navigate('/locales');
            }, 2000);
        } catch (error) {
            console.error('Error al actualizar local:', error);
            setToast({ message: 'Error al actualizar local', state: 'danger' });
        }
    };

    return (
        <div>
            <Nav />
            {toast && <Toast {...toast} />}
            <div className="crear-local-card">
                <h2>Editar Local</h2>
                <form onSubmit={handleSubmit} className="formulario-local">
                    <div className="form-group">
                        <label>Nombre del local:</label>
                        <input
                            type="text"
                            value={nombre}
                            onChange={(e) => setNombre(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Dirección:</label>
                        <input
                            type="text"
                            value={direccion}
                            onChange={(e) => setDireccion(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Vendedores asignados</label>
                        <div className="checkbox-list">
                            {vendedores.map((v) => (
                                <label key={v._id} className="checkbox-item">
                                    <input
                                        type="checkbox"
                                        value={v._id}
                                        checked={vendedoresSeleccionados.includes(v._id)}
                                        onChange={() => handleCheckboxChange(v._id)}
                                    />
                                    {v.nombre} {v.apellido}
                                </label>
                            ))}
                        </div>
                    </div>

                    <button type="submit" className="btn-success">
                        Guardar cambios
                    </button>
                </form>
            </div>
        </div>
    );
};

export default EditarLocalPage;
