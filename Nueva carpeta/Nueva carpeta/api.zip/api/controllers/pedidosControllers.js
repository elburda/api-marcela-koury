// import { Pedido } from "../models/pedidosModels.js";
// import { User } from "../models/userModels.js";

// // Crear pedido
// export const crearPedido = async (req, res) => {
//   try {
//     const { articulos } = req.body;
//     const vendedorId = req.user.id;

//     const nuevo = new Pedido({ vendedor: vendedorId, articulos });
//     await nuevo.save();

//     // Emitir evento socket.io
//     const io = req.app.get('io');
//     io.emit('nuevo-pedido', nuevo);

//     res.status(201).json(nuevo);
//   } catch (err) {
//     console.error("❌ Error al crear el pedido:", err);
//     res.status(500).json({ error: "Error al crear el pedido" });
//   }
// };

// // Obtener pedidos del vendedor autenticado
// export const getPedidosVendedor = async (req, res) => {
//   try {
//     const pedidos = await Pedido.find({ vendedor: req.user.id })
//       .populate("articulos.articulo")
//       .populate("vendedor", "nombre apellido username email");
//     res.json(pedidos);
//   } catch (err) {
//     console.error("❌ Error al obtener pedidos:", err.message);
//     res.status(500).json({ error: "Error al obtener pedidos" });
//   }
// };

// // Actualizar estado de pedido
// export const actualizarEstado = async (req, res) => {
//   try {
//     const pedido = await Pedido.findByIdAndUpdate(
//       req.params.id,
//       { estado: req.body.estado },
//       { new: true }
//     );

//     const io = req.app.get('io');
//     io.emit('pedido-actualizado', pedido);

//     res.json(pedido);
//   } catch (err) {
//     res.status(500).json({ error: "Error al actualizar estado" });
//   }
// };

// // Eliminar pedido
// export const eliminarPedido = async (req, res) => {
//   try {
//     const pedido = await Pedido.findByIdAndDelete(req.params.id);

//     const io = req.app.get('io');
//     io.emit('pedido-eliminado', { id: pedido._id });

//     res.json({ mensaje: "Pedido eliminado", pedido });
//   } catch (err) {
//     res.status(500).json({ error: "Error al eliminar pedido" });
//   }
// };

// // Obtener todos los pedidos agrupados por vendedor (admin)
// export const getPedidosPorVendedor = async (req, res) => {
//   try {
//     const vendedores = await User.find({ rol: "vendedor" });

//     const resultado = await Promise.all(
//       vendedores.map(async (vendedor) => {
//         const pedidos = await Pedido.find({ vendedor: vendedor._id })
//           .populate("articulos.articulo")
//           .populate("vendedor", "nombre apellido email");

//         return {
//           vendedor: {
//             _id: vendedor._id,
//             nombre: vendedor.nombre,
//             apellido: vendedor.apellido,
//             email: vendedor.email
//           },
//           pedidos
//         };
//       })
//     );

//     res.status(200).json(resultado);
//   } catch (error) {
//     console.error("❌ Error al obtener pedidos por vendedor:", error);
//     res.status(500).json({ message: "Error interno del servidor" });
//   }
// };

// // Obtener detalle de pedido por ID (con precios y subtotales)
// export const getPedidoById = async (req, res) => {
//   try {
//     const { id } = req.params;

//     const pedido = await Pedido.findById(id)
//       .populate("articulos.articulo")
//       .populate("vendedor", "nombre apellido email");

//     if (!pedido) {
//       return res.status(404).json({ message: "Pedido no encontrado" });
//     }

//     const articulosFormateados = pedido.articulos.map(item => {
//       const articulo = item.articulo;
//       const cantidad = item.cantidad;
//       const precio = articulo?.price || 0;

//       return {
//         titulo: articulo?.title || '',
//         descripcion: articulo?.description || '',
//         precio,
//         cantidad,
//         subtotal: cantidad * precio
//       };
//     });

//     const total = articulosFormateados.reduce((acc, item) => acc + item.subtotal, 0);

//     const resultado = {
//       _id: pedido._id,
//       estado: pedido.estado,
//       fecha: pedido.fechaPedido || pedido.createdAt,
//       vendedor: {
//         nombre: pedido.vendedor?.nombre || '',
//         email: pedido.vendedor?.email || ''
//       },
//       articulos: articulosFormateados,
//       total
//     };

//     res.json(resultado);
//   } catch (err) {
//     console.error("❌ Error al obtener pedido por ID:", err);
//     res.status(500).json({ message: "Error interno del servidor" });
//   }
// };me hablo me hablo el pibe que quiere la landin


import Pedido from '../models/pedidosModels.js';

// Obtener pedidos del vendedor logueado
export const obtenerMisPedidos = async (req, res) => {
  try {
    const pedidos = await Pedido.find({ vendedor: req.user.id })
      .populate('vendedor', 'nombre email')
      .populate('articulos.articulo');
    res.json(pedidos);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener pedidos', error: err.message });
  }
};

// Obtener pedidos agrupados por vendedor (admin)
export const obtenerPedidosPorVendedor = async (req, res) => {
  try {
    const pedidos = await Pedido.find()
      .populate('vendedor', 'nombre apellido email')
      .populate('articulos.articulo');

    const agrupados = pedidos.reduce((acc, pedido) => {
      // Ignorar pedidos sin vendedor válido
      if (!pedido.vendedor || !pedido.vendedor._id) return acc;

      const idVendedor = pedido.vendedor._id.toString();

      if (!acc[idVendedor]) {
        acc[idVendedor] = {
          vendedor: pedido.vendedor,
          pedidos: []
        };
      }

      acc[idVendedor].pedidos.push(pedido);
      return acc;
    }, {});

    res.json(Object.values(agrupados));
  } catch (err) {
    res.status(500).json({ message: 'Error al agrupar pedidos', error: err.message });
  }
};

// Crear pedido
export const crearPedido = async (req, res) => {
  try {
    const nuevoPedido = new Pedido({
      vendedor: req.user.id,
      articulos: req.body.articulos,
      estado: 'pendiente',
      fechaPedido: new Date()
    });
    await nuevoPedido.save();
    res.status(201).json(nuevoPedido);
  } catch (err) {
    res.status(500).json({ message: 'Error al crear pedido', error: err.message });
  }
};

// Eliminar pedido
export const eliminarPedido = async (req, res) => {
  try {
    const pedido = await Pedido.findById(req.params.id);
    if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

    // Solo el vendedor creador o un admin puede eliminar
    if (pedido.vendedor.toString() !== req.user.id && req.user.rol !== 'admin') {
      return res.status(403).json({ message: 'No autorizado' });
    }

    await pedido.deleteOne();
    res.json({ message: 'Pedido eliminado correctamente' });
  } catch (err) {
    res.status(500).json({ message: 'Error al eliminar pedido', error: err.message });
  }
};

// Obtener pedido por ID (detalle)
export const obtenerPedidoPorId = async (req, res) => {
  try {
    const pedido = await Pedido.findById(req.params.id)
      .populate('vendedor', 'nombre email')
      .populate('articulos.articulo');

    if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

    res.json(pedido);
  } catch (err) {
    res.status(500).json({ message: 'Error al obtener pedido', error: err.message });
  }
};

// ACTUALIZAR pedido (solo estado)
export const actualizarPedido = async (req, res) => {
  try {
    console.log("🟡 Body recibido en actualizarPedido:", req.body);
    const pedido = await Pedido.findById(req.params.id);
    if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

    if (req.body.estado) {
      pedido.estado = req.body.estado;
    }

    await pedido.save();
    res.json({ message: 'Pedido actualizado', pedido });
  } catch (err) {
    console.error("❌ Error en actualizarPedido:", err);
    res.status(500).json({ message: 'Error al actualizar pedido', error: err.message });
  }
};
// Actualizar solo el estado del pedido (PUT /pedidos/:id/estado)
export const actualizarEstadoPedido = async (req, res) => {
  try {
    const { id } = req.params;
    const { estado } = req.body;

    if (!estado) {
      return res.status(400).json({ message: 'El campo "estado" es obligatorio' });
    }

    const pedido = await Pedido.findById(id);
    if (!pedido) {
      return res.status(404).json({ message: 'Pedido no encontrado' });
    }

    pedido.estado = estado;
    await pedido.save();

    res.json({ message: 'Estado actualizado correctamente', pedido });
  } catch (err) {
    console.error('❌ Error al actualizar estado del pedido:', err);
    res.status(500).json({ message: 'Error al actualizar estado del pedido', error: err.message });
  }
};



// Obtener pedido por ID (para otras vistas)
export const getPedidoById = async (req, res) => {
  try {
    const { id } = req.params;
    const pedido = await Pedido.findById(id)
      .populate('vendedor', 'nombre apellido email')
      .populate('articulos.articulo');

    if (!pedido) {
      return res.status(404).json({ message: "Pedido no encontrado" });
    }

    res.json(pedido);
  } catch (error) {
    console.error("❌ Error al obtener pedido por ID:", error);
    res.status(500).json({ message: "Error al obtener el pedido" });
  }
};


// import Pedido from '../models/pedidosModels.js';

// // Obtener pedidos del vendedor logueado
// export const obtenerMisPedidos = async (req, res) => {
//   try {
//     const pedidos = await Pedido.find({ vendedor: req.user.id })
//       .populate('vendedor', 'nombre email')
//       .populate('articulos.articulo');
//     res.json(pedidos);
//   } catch (err) {
//     res.status(500).json({ message: 'Error al obtener pedidos', error: err.message });
//   }
// };

// // Obtener pedidos agrupados por vendedor (admin)
// export const obtenerPedidosPorVendedor = async (req, res) => {
//   try {
//     const pedidos = await Pedido.find()
//       .populate('vendedor', 'nombre apellido email')
//       .populate('articulos.articulo');

//     const agrupados = pedidos.reduce((acc, pedido) => {
//       if (!pedido.vendedor || !pedido.vendedor._id) return acc;
//       const idVendedor = pedido.vendedor._id.toString();
//       if (!acc[idVendedor]) {
//         acc[idVendedor] = { vendedor: pedido.vendedor, pedidos: [] };
//       }
//       acc[idVendedor].pedidos.push(pedido);
//       return acc;
//     }, {});

//     res.json(Object.values(agrupados));
//   } catch (err) {
//     res.status(500).json({ message: 'Error al agrupar pedidos', error: err.message });
//   }
// };

// // Crear pedido
// export const crearPedido = async (req, res) => {
//   try {
//     const nuevoPedido = new Pedido({
//       vendedor: req.user.id,
//       articulos: req.body.articulos,
//       estado: 'pendiente',
//       fechaPedido: new Date()
//     });
//     await nuevoPedido.save();
//     res.status(201).json(nuevoPedido);
//   } catch (err) {
//     res.status(500).json({ message: 'Error al crear pedido', error: err.message });
//   }
// };

// // Eliminar pedido
// export const eliminarPedido = async (req, res) => {
//   try {
//     const pedido = await Pedido.findById(req.params.id);
//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });
//     if (pedido.vendedor.toString() !== req.user.id && req.user.rol !== 'admin') {
//       return res.status(403).json({ message: 'No autorizado' });
//     }
//     await pedido.deleteOne();
//     res.json({ message: 'Pedido eliminado correctamente' });
//   } catch (err) {
//     res.status(500).json({ message: 'Error al eliminar pedido', error: err.message });
//   }
// };

// // Obtener pedido por ID
// export const obtenerPedidoPorId = async (req, res) => {
//   try {
//     const pedido = await Pedido.findById(req.params.id)
//       .populate('vendedor', 'nombre email')
//       .populate('articulos.articulo');

//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });
//     res.json(pedido);
//   } catch (err) {
//     res.status(500).json({ message: 'Error al obtener pedido', error: err.message });
//   }
// };

// // Actualizar pedido completo
// export const actualizarPedido = async (req, res) => {
//   try {
//     const pedido = await Pedido.findById(req.params.id);
//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

//     // actualizar artículos u otros campos
//     if (req.body.articulos) {
//       pedido.articulos = req.body.articulos;
//     }
//     if (req.body.estado) {
//       pedido.estado = req.body.estado;
//     }

//     await pedido.save();
//     res.json({ message: 'Pedido actualizado', pedido });
//   } catch (err) {
//     res.status(500).json({ message: 'Error al actualizar pedido', error: err.message });
//   }
// };

// // ✅ NUEVO controlador para actualizar solo el estado
// export const actualizarEstadoPedido = async (req, res) => {
//   try {
//     const { estado } = req.body;
//     const pedido = await Pedido.findById(req.params.id);
//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

//     pedido.estado = estado;
//     await pedido.save();

//     res.json({ message: 'Estado actualizado', pedido });
//   } catch (err) {
//     console.error("❌ Error en actualizarEstadoPedido:", err);
//     res.status(500).json({ message: 'Error al actualizar estado del pedido' });
//   }
// };

// // Alias por compatibilidad
// export const getPedidoById = obtenerPedidoPorId;


// import Pedido from '../models/pedidosModels.js';

// // Obtener pedidos del vendedor logueado
// export const obtenerMisPedidos = async (req, res) => {
//   try {
//     const pedidos = await Pedido.find({ vendedor: req.user.id })
//       .populate('vendedor', 'nombre email')
//       .populate('articulos.articulo');
//     res.json(pedidos);
//   } catch (err) {
//     res.status(500).json({ message: 'Error al obtener pedidos', error: err.message });
//   }
// };

// // Obtener pedidos agrupados por vendedor (admin)
// export const obtenerPedidosPorVendedor = async (req, res) => {
//   try {
//     const pedidos = await Pedido.find()
//       .populate('vendedor', 'nombre apellido email')
//       .populate('articulos.articulo');

//     const agrupados = pedidos.reduce((acc, pedido) => {
//       // Ignorar pedidos sin vendedor válido
//       if (!pedido.vendedor || !pedido.vendedor._id) return acc;

//       const idVendedor = pedido.vendedor._id.toString();

//       if (!acc[idVendedor]) {
//         acc[idVendedor] = {
//           vendedor: pedido.vendedor,
//           pedidos: []
//         };
//       }

//       acc[idVendedor].pedidos.push(pedido);
//       return acc;
//     }, {});

//     res.json(Object.values(agrupados));
//   } catch (err) {
//     res.status(500).json({ message: 'Error al agrupar pedidos', error: err.message });
//   }
// };

// // Crear pedido
// export const crearPedido = async (req, res) => {
//   try {
//     const nuevoPedido = new Pedido({
//       vendedor: req.user.id,
//       articulos: req.body.articulos,
//       estado: 'pendiente',
//       fechaPedido: new Date()
//     });
//     await nuevoPedido.save();
//     res.status(201).json(nuevoPedido);
//   } catch (err) {
//     res.status(500).json({ message: 'Error al crear pedido', error: err.message });
//   }
// };

// // Eliminar pedido
// export const eliminarPedido = async (req, res) => {
//   try {
//     const pedido = await Pedido.findById(req.params.id);
//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

//     // Solo el vendedor creador o un admin puede eliminar
//     if (pedido.vendedor.toString() !== req.user.id && req.user.rol !== 'admin') {
//       return res.status(403).json({ message: 'No autorizado' });
//     }

//     await pedido.deleteOne();
//     res.json({ message: 'Pedido eliminado correctamente' });
//   } catch (err) {
//     res.status(500).json({ message: 'Error al eliminar pedido', error: err.message });
//   }
// };

// // Obtener pedido por ID (detalle)
// export const obtenerPedidoPorId = async (req, res) => {
//   try {
//     const pedido = await Pedido.findById(req.params.id)
//       .populate('vendedor', 'nombre email')
//       .populate('articulos.articulo');

//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

//     res.json(pedido);
//   } catch (err) {
//     res.status(500).json({ message: 'Error al obtener pedido', error: err.message });
//   }
// };

// // ACTUALIZAR pedido (solo estado)
// export const actualizarPedido = async (req, res) => {
//   try {
//     console.log("🟡 Body recibido en actualizarPedido:", req.body);
//     const pedido = await Pedido.findById(req.params.id);
//     if (!pedido) return res.status(404).json({ message: 'Pedido no encontrado' });

//     if (req.body.estado) {
//       pedido.estado = req.body.estado;
//     }

//     await pedido.save();
//     res.json({ message: 'Pedido actualizado', pedido });
//   } catch (err) {
//     console.error("❌ Error en actualizarPedido:", err);
//     res.status(500).json({ message: 'Error al actualizar pedido', error: err.message });
//   }
// };
// // Actualizar solo el estado del pedido (PUT /pedidos/:id/estado)
// export const actualizarEstadoPedido = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const { estado } = req.body;

//     if (!estado) {
//       return res.status(400).json({ message: 'El campo "estado" es obligatorio' });
//     }

//     const pedido = await Pedido.findById(id);
//     if (!pedido) {
//       return res.status(404).json({ message: 'Pedido no encontrado' });
//     }

//     pedido.estado = estado;
//     await pedido.save();

//     res.json({ message: 'Estado actualizado correctamente', pedido });
//   } catch (err) {
//     console.error('❌ Error al actualizar estado del pedido:', err);
//     res.status(500).json({ message: 'Error al actualizar estado del pedido', error: err.message });
//   }
// };



// // Obtener pedido por ID (para otras vistas)
// export const getPedidoById = async (req, res) => {
//   try {
//     const { id } = req.params;
//     const pedido = await Pedido.findById(id)
//       .populate('vendedor', 'nombre apellido email')
//       .populate('articulos.articulo');

//     if (!pedido) {
//       return res.status(404).json({ message: "Pedido no encontrado" });
//     }

//     res.json(pedido);
//   } catch (error) {
//     console.error("❌ Error al obtener pedido por ID:", error);
//     res.status(500).json({ message: "Error al obtener el pedido" });
//   }
// };
