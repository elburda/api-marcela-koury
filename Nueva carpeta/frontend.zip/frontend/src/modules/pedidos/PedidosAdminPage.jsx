// import React, { useEffect, useState } from 'react';
// import { getPedidosPorVendedor, eliminarPedido } from '../../services/pedidosService';
// import PedidoCard from './components/PedidoCard';
// import Nav from '../../components/Nav';
// import Toast from '../../components/Toast';
// import { useLocation } from 'react-router-dom';
// import Swal from 'sweetalert2';
// import { io } from 'socket.io-client';
// import './PedidosPage.scss';

// const socket = io('http://localhost:3000');

// const PedidosAdminPage = () => {
//     const [pedidosPorVendedor, setPedidosPorVendedor] = useState([]);
//     const [toast, setToast] = useState(null);
//     const location = useLocation();

//     const cargarPedidos = async () => {
//         try {
//         const data = await getPedidosPorVendedor();
//         setPedidosPorVendedor(data);
//         } catch (err) {
//         console.error('Error al obtener pedidos:', err);
//         }
//     };

//     useEffect(() => {
//         cargarPedidos();

//         socket.on('nuevo-pedido', () => {
//         console.log('🟢 Pedido nuevo recibido');
//         cargarPedidos();
//         });

//         socket.on('pedido-actualizado', () => {
//         console.log('🔄 Pedido actualizado');
//         cargarPedidos();
//         });

//         socket.on('pedido-eliminado', () => {
//         console.log('🗑 Pedido eliminado');
//         cargarPedidos();
//         });

//         return () => {
//         socket.off('nuevo-pedido');
//         socket.off('pedido-actualizado');
//         socket.off('pedido-eliminado');
//         };
//     }, []);

//     useEffect(() => {
//         if (location.state?.toast) {
//         setToast(location.state.toast);
//         setTimeout(() => setToast(null), 4000);
//         }
//     }, [location.state]);

//     const handleDelete = async (id) => {
//         const confirm = await Swal.fire({
//         title: '¿Estás seguro?',
//         text: 'Esta acción eliminará el pedido permanentemente.',
//         icon: 'warning',
//         showCancelButton: true,
//         confirmButtonText: 'Sí, eliminar',
//         cancelButtonText: 'Cancelar',
//         });

//         if (confirm.isConfirmed) {
//         try {
//             await eliminarPedido(id);
//             await cargarPedidos();
//             setToast({ message: 'Pedido eliminado correctamente.', state: 'success' });
//             setTimeout(() => setToast(null), 4000);
//         } catch (err) {
//             console.error('Error al eliminar pedido:', err);
//         }
//         }
//     };

//     return (
//         <div>
//         <Nav />
//         {toast && <Toast {...toast} />}
//         <div className="contenedor-pedidos">
//             {pedidosPorVendedor.map((vendedor) => (
//             <div key={vendedor._id} className="tarjeta-vendedor">
//                 <h2>{vendedor.nombre} {vendedor.apellido}</h2>
//                 <div className="pedidos-lista">
//                 {vendedor.pedidos.map((pedido) => (
//                     <PedidoCard key={pedido._id} pedido={pedido} onDelete={handleDelete} />
//                 ))}
//                 </div>
//             </div>
//             ))}
//         </div>
//         </div>
//     );
// };

// export default PedidosAdminPage;

import React, { useEffect, useState } from 'react';
import { getPedidosPorVendedor, eliminarPedido } from '../../services/pedidosService';
import PedidoCard from './components/PedidoCard';
import Nav from '../../components/Nav';
import Toast from '../../components/Toast';
import { useLocation } from 'react-router-dom';
import Swal from 'sweetalert2';
import { io } from 'socket.io-client';
import './PedidosPage.scss';

const socket = io('http://localhost:3000');

const PedidosAdminPage = () => {
    const [pedidosPorVendedor, setPedidosPorVendedor] = useState([]);
    const [toast, setToast] = useState(null);
    const location = useLocation();

    const cargarPedidos = async () => {
        try {
        const data = await getPedidosPorVendedor();
        setPedidosPorVendedor(data);
        } catch (err) {
        console.error('Error al obtener pedidos:', err);
        }
    };

    useEffect(() => {
        cargarPedidos();

        socket.on('nuevo-pedido', cargarPedidos);
        socket.on('pedido-actualizado', cargarPedidos);
        socket.on('pedido-eliminado', cargarPedidos);

        return () => {
        socket.off('nuevo-pedido', cargarPedidos);
        socket.off('pedido-actualizado', cargarPedidos);
        socket.off('pedido-eliminado', cargarPedidos);
        };
    }, []);

    useEffect(() => {
        if (location.state?.toast) {
        setToast(location.state.toast);
        setTimeout(() => setToast(null), 4000);
        }
    }, [location.state]);

    const handleDelete = async (id) => {
        const confirm = await Swal.fire({
        title: '¿Estás seguro?',
        text: 'Esta acción eliminará el pedido permanentemente.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar',
        });

        if (confirm.isConfirmed) {
        try {
            await eliminarPedido(id);
            await cargarPedidos();
            setToast({ message: 'Pedido eliminado correctamente.', state: 'success' });
            setTimeout(() => setToast(null), 4000);
        } catch (err) {
            console.error('Error al eliminar pedido:', err);
        }
        }
    };

    return (
        <div>
        <Nav />
        {toast && <Toast {...toast} />}
        <div className="contenedor-pedidos">
            {pedidosPorVendedor.map((vendedorItem) => (
            <div key={vendedorItem.vendedor._id} className="tarjeta-vendedor">
                <h2>{vendedorItem.vendedor.nombre} {vendedorItem.vendedor.apellido}</h2>
                <div className="pedidos-lista">
                <PedidoCard
                    key={vendedorItem.vendedor._id}
                    vendedor={vendedorItem.vendedor}
                    pedidos={vendedorItem.pedidos}
                    onDelete={handleDelete}
                />
                </div>
            </div>
            ))}
        </div>
        </div>
    );
};

export default PedidosAdminPage;
