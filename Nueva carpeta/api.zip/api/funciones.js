

export function sumar(a,b){
    return a + b;
}


export default function restar(a,b){
    return a + b;
}